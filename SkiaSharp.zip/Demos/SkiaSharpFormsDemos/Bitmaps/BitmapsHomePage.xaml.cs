﻿namespace SkiaSharpFormsDemos.Bitmaps
{
    public partial class BitmapsHomePage : HomeBasePage
    {
        public BitmapsHomePage ()
        {
            InitializeComponent ();
        }
    }
}