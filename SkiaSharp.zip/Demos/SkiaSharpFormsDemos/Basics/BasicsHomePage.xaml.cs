﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SkiaSharpFormsDemos.Basics
{
    public partial class BasicsHomePage : HomeBasePage
    {
        public BasicsHomePage()
        {
            InitializeComponent();
        }
    }
}
