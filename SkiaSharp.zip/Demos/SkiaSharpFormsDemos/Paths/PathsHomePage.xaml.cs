﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SkiaSharpFormsDemos.Paths
{
    public partial class PathsHomePage : HomeBasePage
    {
        public PathsHomePage()
        {
            InitializeComponent();
        }
    }
}
